// Copyright (c) 2020-2024 Bluespec, Inc.  All Rights Reserved
// Author: Rishiyur S.Nikhil

// Please see Elf_read.c for documentation

#pragma once

// Nothing in this file

#define RC_OK  0
#define RC_ERR 1

// ================================================================
